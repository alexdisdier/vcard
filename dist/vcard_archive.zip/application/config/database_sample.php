<?php

/*
 * Database configuration settings used by PDO.
 * If you need to use the file,
 * make sure you change the name of the file to database.php and earase
 * the other database.php
 */

$config['dsn']      = 'mysql:host=localhost;dbname=alexdisd_vcard';
$config['password'] = 'root';
$config['user']     = 'root';
