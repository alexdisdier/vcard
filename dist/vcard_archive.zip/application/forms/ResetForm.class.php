<?php

class ResetForm extends Form
{
    public function build()
    {
        $this->addFormField('email');
    }
}
