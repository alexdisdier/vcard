<?php

class AdminUserForm extends Form
{
    public function build()
    {
        $this->addFormField('email');
    }
}