<?php

class TokenForm extends Form
{
    public function build()
    {
        $this->addFormField('email');
    }
}
