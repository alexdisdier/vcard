
<?php
/**
 * This is the index.php
 */
require('header.phtml');
?>

<!-- Shows the template linked to the view -->
<?php include $this->viewData['template'] ?>

<?php
require('footer.phtml');?>
